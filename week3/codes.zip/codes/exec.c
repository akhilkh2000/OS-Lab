#include<stdio.h>
#include<unistd.h>

int main() {
	printf("In a process(exec.c) called by exec in child...\n");
	return 0;
}